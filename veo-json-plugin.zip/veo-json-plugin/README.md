
# JSON→Video Prompt Compiler (MVP)

**What this is:** A tiny service + schema that turns structured JSON into a well‑formatted, provider-ready text prompt (e.g., Veo 3). It exposes a FastAPI endpoint and an OpenAPI spec you can register as a ChatGPT Action.

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn src.api:app --reload --port 8000
```

## Try it

```bash
curl -X POST http://localhost:8000/compile -H "Content-Type: application/json" \
  -d @examples/example_veo_asmr.json
```

## Files

- `schema/video_prompt.schema.json` – JSON Schema for validation
- `src/compiler.py` – Core renderer to produce the prompt text
- `src/providers/` – Provider adapters (Veo, Generic). Add Runway/Pika/etc. as needed.
- `src/api.py` – FastAPI server exposing `/compile` and `/health`
- `openapi.yaml` – ChatGPT Action spec
- `examples/example_veo_asmr.json` – A working example (glossy cake ASMR, 9:16 loop)

## Extend to Real APIs

This MVP returns text. To actually hit vendor APIs, create provider adapters that translate this schema to each provider's API parameters, authenticate with their keys, and POST the request. Keep the JSON → prompt step, because most tools still benefit from strong textual prompts.

## Notes

- Schema is permissive. Add required fields for your workflow.
- Layers/masks are included for tools that support selective generation or compositing.
- Negative prompts: You can set per-shot `negative_prompt` and global `compile.negative_prompt_global`.

Generated on: 2025-08-08T23:26:43.901444
