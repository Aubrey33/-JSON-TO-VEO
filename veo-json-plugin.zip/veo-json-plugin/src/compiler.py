
import json
from typing import Dict, Any, List

def seconds_str(v):
    try:
        if v is None:
            return None
        iv = float(v)
        if abs(iv - int(iv)) < 1e-6:
            return f"{int(iv)}s"
        return f"{iv:.2f}s"
    except Exception:
        return None

def render_shot(i: int, shot: Dict[str, Any]) -> str:
    parts = []
    sid = shot.get("id") or f"shot_{i+1}"
    parts.append(f"### Shot {i+1} ({sid})")
    if shot.get("prompt"):
        parts.append(f"- Prompt: {shot['prompt']}")
    if shot.get("subject"): parts.append(f"- Subject: {shot['subject']}")
    if shot.get("action"): parts.append(f"- Action: {shot['action']}")
    if shot.get("environment"): parts.append(f"- Environment: {shot['environment']}")
    if shot.get("composition"): parts.append(f"- Composition: {shot['composition']}")
    if shot.get("camera_motion"): parts.append(f"- Camera: {shot['camera_motion']}")
    if shot.get("vfx"): parts.append(f"- VFX: {shot['vfx']}")
    if shot.get("duration_sec") or shot.get("frames"):
        dur = seconds_str(shot.get("duration_sec"))
        fr = shot.get("frames")
        timing = " / ".join(x for x in [dur, f\"{fr}f\" if fr else None] if x)
        parts.append(f"- Timing: {timing}")
    if shot.get("negative_prompt"):
        parts.append(f"- Negative: {shot['negative_prompt']}")
    layers = shot.get("layers") or []
    if layers:
        parts.append("- Layers:")
        for L in layers:
            parts.append(f"  - {L.get('name','layer')}: {L.get('mask_prompt','')} (blend={L.get('blend_mode','normal')}, opacity={L.get('opacity',1.0)})")
    return "\n".join(parts)

def render_transitions(data: Dict[str, Any]) -> str:
    trs = data.get("transitions") or []
    if not trs: return ""
    out = ["## Transitions"]
    for t in trs:
        out.append(f"- {t.get('from','?')} → {t.get('to','?')}: {t.get('type','')} ({t.get('notes','')})")
    return "\n".join(out)

def render_prompt(data: Dict[str, Any], provider: str = "generic") -> str:
    out: List[str] = []
    meta = data.get("output", {})
    style = data.get("style", {})
    audio = data.get("audio", {})
    safety = data.get("safety", {})
    compile_opts = data.get("compile", {})

    # Header
    out.append(f"# {provider.upper()} — Video Prompt")
    aspect = meta.get("aspect", "16:9")
    dims = "x".join(str(meta.get(k)) for k in ("width", "height") if meta.get(k))
    meta_line = f"Aspect: {aspect}"
    if dims: meta_line += f" | Resolution: {dims}"
    if meta.get("fps"): meta_line += f" | FPS: {meta.get('fps')}"
    if meta.get("duration_sec"): meta_line += f" | Duration: {seconds_str(meta.get('duration_sec'))}"
    if meta.get("loop"): meta_line += " | Loop: on"
    out.append(meta_line)

    # Style
    out.append("## Style")
    if style.get("look"): out.append(f"- Look: {style['look']}")
    if style.get("color_palette"): out.append(f"- Colors: {style['color_palette']}")
    if style.get("lighting"): out.append(f"- Lighting: {style['lighting']}")
    if style.get("mood"): out.append(f"- Mood: {style['mood']}")
    if style.get("cinematography"): out.append(f"- Cinematography: {style['cinematography']}")
    cam = style.get("camera", {})
    if cam:
        seg = ", ".join([
            f"{cam.get('lens_mm')}mm lens" if cam.get("lens_mm") else "",
            f"DOF: {cam.get('dof')}" if cam.get("dof") else "",
            f"Shutter: {cam.get('shutter_style')}" if cam.get("shutter_style") else ""
        ])
        seg = ", ".join([s for s in seg.split(", ") if s])
        if seg:
            out.append(f"- Camera: {seg}")

    # Audio
    if audio:
        out.append("## Audio")
        if audio.get("bgm"): out.append(f"- Music: {audio['bgm']}")
        if audio.get("bpm"): out.append(f"- BPM: {audio['bpm']}")
        sfx = audio.get("sfx") or []
        if sfx: out.append(f"- SFX: {', '.join(sfx)}")

    # Safety/Negatives
    if safety or compile_opts.get("negative_prompt_global"):
        out.append("## Constraints")
        if compile_opts.get("negative_prompt_global"):
            out.append(f"- Global Negative: {compile_opts['negative_prompt_global']}")
        if safety.get("nsfw") is not None:
            out.append(f"- NSFW: {'disallow' if safety.get('nsfw') else 'not intended'}")
        dl = safety.get("disallowed") or []
        if dl:
            out.append(f"- Disallowed: {', '.join(dl)}")

    # Shots
    out.append("## Shots")
    for i, sh in enumerate(data.get("shots", [])):
        out.append(render_shot(i, sh))

    # Transitions
    tr = render_transitions(data)
    if tr: out.append(tr)

    # Compile hints
    if compile_opts:
        out.append("## Generation Hints")
        if compile_opts.get("seed") is not None: out.append(f"- Seed: {compile_opts['seed']}")
        if compile_opts.get("guidance") is not None: out.append(f"- Guidance: {compile_opts['guidance']}")

    return "\n\n".join(out)
