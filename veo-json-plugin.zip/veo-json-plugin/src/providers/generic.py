
from typing import Dict, Any
from .shared import base_render

def render(data: Dict[str, Any]) -> str:
    return base_render(data, provider="Generic")
