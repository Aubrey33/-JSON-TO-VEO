
from typing import Dict, Any
from ..compiler import render_prompt

def base_render(data: Dict[str, Any], provider: str) -> str:
    # Currently delegates to generic renderer; place to inject provider nuances
    return render_prompt(data, provider=provider)
