
from typing import Dict, Any
from .shared import base_render

def render(data: Dict[str, Any]) -> str:
    # Veo-specific tweak: emphasize cinematography and camera motion
    txt = base_render(data, provider="VEO 3")
    # Could add Veo-specific tags or formatting here if needed
    return txt
