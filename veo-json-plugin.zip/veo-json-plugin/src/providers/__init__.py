
from . import veo3, generic

def by_name(name: str):
    name = (name or "generic").lower()
    if name == "veo3":
        return veo3
    return generic
