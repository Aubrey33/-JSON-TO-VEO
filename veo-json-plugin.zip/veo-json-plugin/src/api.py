
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any, Dict
from jsonschema import validate, ValidationError
import json, pathlib
from .compiler import render_prompt
from .providers import by_name

app = FastAPI(title="JSON→Video Prompt Compiler", version="1.0.0")

SCHEMA_PATH = pathlib.Path(__file__).resolve().parents[1] / "schema" / "video_prompt.schema.json"
SCHEMA = json.loads(SCHEMA_PATH.read_text())

class CompileBody(BaseModel):
    data: Dict[str, Any]

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/compile")
def compile_prompt(body: CompileBody):
    data = body.data
    try:
        validate(instance=data, schema=SCHEMA)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Schema validation error: {e.message}")
    provider = (data.get("provider") or "generic").lower()
    renderer = by_name(provider)
    prompt_text = renderer.render(data)
    return {"provider": provider, "prompt": prompt_text}

@app.post("/compile/raw")
def compile_raw(body: CompileBody):
    # Skip schema validation (for quick experiments)
    data = body.data
    provider = (data.get("provider") or "generic").lower()
    renderer = by_name(provider)
    prompt_text = renderer.render(data)
    return {"provider": provider, "prompt": prompt_text}
